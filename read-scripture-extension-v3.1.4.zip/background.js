(()=>{"use strict";chrome.runtime.onInstalled.addListener((function(){console.log("Extension installed")}))})();
//# sourceMappingURL=background.js.map